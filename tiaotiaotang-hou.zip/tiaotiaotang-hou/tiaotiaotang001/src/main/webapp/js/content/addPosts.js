$(function () {
    /*利用ajax拿到主题分类classify*/
    $.ajax({
        url:"/classify/getAllClassify",
        type:"get",
        data:"",
        dataType:"json",
        success:function (data) {
            if(data && data.length > 0) {
                $.each(data, function(i,m){
                    $("#classify_select").append("<option value='"+m.classid+"'>"+m.classname+"</option>");
                })
            }
        }
    })
    /*当选中的分类改变时，要把新的分类classid放到隐藏域中*/
    $("#classify_select").change(function () {
        var classid=$("#classify_select option:selected").val();
        $("#classid").attr("value",classid);
    })
    //获取时间戳，往数据库添加时用得到
    function getTimestamp(){
        var time=new Date();
        var year=time.getFullYear();
        var month=time.getMonth()+1;
        var day=time.getDate();
        var hour=time.getHours();
        var minu=time.getMinutes();
        var second=time.getMinutes();
        return(year+"-"+month+"-"+day+" "+hour+":"+minu+":"+second);
    }
    /*先控制字数*/
    var ptitlezi=false;//标题字数控制
    var pcontentzi=false//内容字数控制
    $("#ptitle").keyup(function(){
        var zi=$("#ptitle").val().length;
        $("#zishu1").html(20-zi);
        if(zi<=20&&zi>0){
            ptitlezi=true;
        }else{
            ptitlezi=false;
        }
    })
    $("#pcontent").keyup(function(){
        var zi=$("#pcontent").val().length;
        $("#zishu2").html(251-zi);
        if(zi<=251&&zi>0){
            pcontentzi=true;
        }else{
            pcontentzi=false;
        }
    })

    $("#addBtn").click(function () {
        var timestamp=getTimestamp();
        $("#pdate").attr("value",timestamp);
        if(ptitlezi==true&&pcontentzi==true){
            $("#addPostsForm").submit();
        }else {
            alert("字数有点多喔～")
        }
    })

    var imgSize=3;//控制上传图片数量
    $(function () {
        $("#pic").change(function () {
            //控制上传图片数量
            if (imgSize<=0){
                alert("只能3张喔");
                return;
            }
            //上传的请求
            $("#empForm").ajaxSubmit({
                url:basePath()+'/postsimg/upload_ajax',
                type:'post',
                dataType:'json',
                success:function (data) {
                    //回填数据到隐藏域
                    $("#picFile").val(data);
                    var imgval=$("#imgurl").val()
                    imgval+=data+";";
                    $("#imgurl").val(imgval);
                    imgSize--;
                    $("#imgcishu").html(imgSize);
                    //回显图片
                    //$("img").attr("src","/uploadFile_ajax/"+data);
                    $("#ul_img").append("<li><img src='"+basePath()+"/images/posts/"+data+"'></li>")
                }
            });
        });

    });

    /*获取basePath*/
    function basePath(){
        //获取当前网址，如： http://localhost:8080/ems/Pages/Basic/Person.jsp
        var curWwwPath = window.document.location.href;
        //获取主机地址之后的目录，如： /ems/Pages/Basic/Person.jsp
        var pathName = window.document.location.pathname;
        var pos = curWwwPath.indexOf(pathName);
        //获取主机地址，如： http://localhost:8080
        var localhostPath = curWwwPath.substring(0, pos);
        //获取带"/"的项目名，如：/ems
        var projectName = pathName.substring(0, pathName.substr(1).indexOf('/') + 1);
        //获取项目的basePath   http://localhost:8080/ems/
        //var basePath=localhostPath+projectName+"/";
        var basePath=localhostPath
        return basePath;
    };
})