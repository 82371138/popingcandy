
    var name = false;
    var pwd = false
    function panduan1() {
        var aname = $("#aname").val();
        if (aname == "" || aname == null) {
            $("#anameSpan").html("这个不能是空的")
            return name = false;
        } else {
            $("#anameSpan").html("")
            return name = true;
        }
    }

    function panduan2() {
        var apwd = $("#apwd").val();
        if (apwd == "" || apwd == null) {
            $("#apwdSpan").html("这个不能是空的")
            return pwd = false;
        } else {
            $("#apwdSpan").html("")
            return pwd = true;
        }
    }
    $(function () {
        $("#btn_sub").click(function() {
            if (name && pwd) {
                console.info("提交")
                $("#admin_form").submit();
            }
        })
    })
