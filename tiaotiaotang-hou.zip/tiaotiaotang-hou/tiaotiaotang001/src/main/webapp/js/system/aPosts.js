$(function () {
    postsinit();//文章标题，内容，作者，时间初始化
    postsimginit();//文章附带图片初始化
    //postsCominit();//评论区初始化
    //setTimeout('postsCominit()',2000)
    /*window.setTimeout(function () {
        postsCominit()
    },2000)*/
    function postsinit() {
        //获取隐藏域pid的值
        var pid=$("#pid_span").text();
        //获取标题，内容，时间
        $.ajax({
            url:"/posts/getAPosts",
            type:"get",
            data:"pid="+pid,
            dataType:"json",
            success:function (data) {
                if(data) {
                    $("#posts_title").html(data.ptitle);
                    $("#posts_content").html(data.pcontent);
                    $("#name_span").html(getUnickname(data.uid))
                    $("#time_span").html(data.pdate);
                    $("#classify_span").html(getClassifyName(data.classid))
                }
            }
        });
    }
    /*文章附带的图片*/
    function postsimginit() {
        //获取隐藏域pid的值
        var pid=$("#pid_span").text();
        $.ajax({
            url:"/postsimg/getImgList",
            type:"get",
            data:"pid="+pid,
            dataType:"json",
            success:function (data) {
                if(data) {
                    $.each(data, function(i,m){
                        $("#posts_imgul").append("<li><img src='"+basePath()+"/images/posts/"+m.imgurl+"'></li>")
                    })
                }
            }
        })
    }

    /*评论区*/
    /*function postsCominit(){
        //获取隐藏域pid的值
        var pid=$("#pid_span").text();
        $.ajax({
            url:"/postscom/getComList",
            type:"get",
            data:"pid="+pid,
            dataType:"json",
            success:function (data) {
                if(data) {
                    $.each(data, function(i,m){
                        var qqimgurl=getQQimgurl(m.pCqq);
                        var qqname=getQQname(m.pCqq);
                        var date=m.pCdate;
                        var ipaddress=getIPaddress1(m.pCip);
                        var comment=m.pCping;
                        //alert(qqname+qqimgurl+date+ipaddress)
                        $("#postsCom_div").append("" +
                            "<div class='postsCom_div_big'>" +
                            "<div class='user_info'>" +
                            "<ul class='user_info_ul'>" +
                            "<li><img class='user_info_img' src='"+qqimgurl+"'></li>" +
                            "<li>昵称:<span class='user_info_name'>"+qqname+"</span></li>" +
                            "<li>来自:<span class='user_info_address'>"+ipaddress+"</span></li>" +
                            "<li>时间:<span class='user_info_date'>"+date+"</span></li>" +
                            "</ul>" +
                            "</div>" +
                            "<div class='postsCom_info'>"+comment+"</div>" +
                            "</div>")
                    })
                }
            }
        })
    }*/
    postsComPage(1);
    function postsComPage(pageNo) {
        //获取隐藏域pid的值
        var pid=$("#pid_span").text();
        $.ajax({
            url:"/postscom/getComListByPage",
            type:"get",
            data:{"pageNum":pageNo,"pid":pid},
            dataType:"json",
            success:function (data) {
                if (data.list){
                    $("#postsCom_div").empty();
                    //var list=data.list;获取返回的list集合
                    var pageNum=data.pageNum;//获取当前页数
                    var totalPages=data.pages;//获取总页数
                    $.each(data.list, function(i,m){
                        var qqimgurl=getQQimgurl(m.pCqq);
                        var qqname=getQQname(m.pCqq);
                        var date=m.pCdate;
                        var ipaddress=getIPaddress1(m.pCip);
                        var comment=m.pCping;
                        //alert(qqname+qqimgurl+date+ipaddress)
                        $("#postsCom_div").append("" +
                            "<div class='postsCom_div_big'>" +
                            "<div class='user_info'>" +
                            "<ul class='user_info_ul'>" +
                            "<li><img class='user_info_img' src='"+qqimgurl+"'></li>" +
                            "<li>昵称:<span class='user_info_name'>"+qqname+"</span></li>" +
                            "<li>来自:<span class='user_info_address'>"+ipaddress+"</span></li>" +
                            "<li>时间:<span class='user_info_date'>"+date+"</span></li>" +
                            "</ul>" +
                            "</div>" +
                            "<div class='postsCom_info'>"+comment+"</div>" +
                            "</div>")
                    })
                }
                $("#posts_pageCon a:eq(0)").attr("href","javascript:").click(function () {
                    postsComPage(1)
                });
                $("#posts_pageCon a:eq(1)").attr("href","javascript:").click(function () {
                    pageNum--;//单独写出可避免页面加载慢造成的闪烁
                    postsComPage(pageNum);
                });
                $("#posts_pageCon a:eq(2)").attr("href","javascript:").click(function () {
                    pageNum++;
                    postsComPage(pageNum)
                });
                $("#posts_pageCon a:eq(3)").attr("href","javascript:").click(function () {
                    postsComPage(totalPages);
                })
                //当前页和总页数的显示
                $("#pg").html(pageNum+"/"+totalPages+"页");
            }
        })
    }
    /*控制各种输入合法化，以防止出现空值，超长度字符串*/
    var com_textarea=false;//评论字数控制
    var com_qq=false//qq输入框控制
    var com_code=false//验证码控制
    $("#addcom_div_area").keyup(function () {
        var zishu=$("#addcom_div_area").text().length;
        $("#tip_zishu").html(80-zishu);
        if(zishu>0&&zishu<=80){
            com_textarea=true;
        }else {
            com_textarea=false;
        }
    })
    $("#com_getqq").keyup(function () {
        var zishu=$("#com_getqq").val().length;
        if (zishu>0&&zishu<=18){
            com_qq=true;
        }else {
            com_qq=false;
        }
    })
    $("#com_getcode").blur(function () {
        var code1=$("#com_getcode").val();//用户输入的code
        var code2=$("#yzcode").val();//隐藏域的code
        if (code1==code2){
            com_code=true;
            $("#code_msg_span").html("正确");
        }else {
            com_code=false;
            $("#code_msg_span").html("错误");
        }
    })
    /*QQ输入框失焦获取QQinfo*/
    $("#com_getqq").blur(function () {
        var qq=$("#com_getqq").val();
        $.ajax({
            url:"/qq/getqqInfo",
            type:"get",
            data:"qq="+qq,
            datatype:"json",
            success:function (data) {
                if (data){
                    $("#icon_touimg").attr("src",data.imgurl);
                    $("#qq_name").html(data.name)
                }
            }
        })
    })
    /*获取IP信息*/
    $.ajax({
        url:"/ip/getIPInfo",
        type:"get",
        data:"",
        datatype:"json",
        success:function (data) {
            if (data){
                $("#tip_ip").html(data.data.ip);
                $("#tip_address").html(data.data.pos);
            }
        }
    })
    /*随机生成验证码,并调用*/
    createCode();
    function createCode() {
        code = "";
        var codeLength = 4;//验证码的长度，可变
        var canvas=document.getElementById('myCanvas');//获取画布
        var selectChar = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');//所有候选组成验证码的字符

        for (var i = 0; i < codeLength; i++) {
            var charIndex = Math.floor(Math.random() * 36);
            code += selectChar[charIndex];
        }
        if (canvas) {
            var ctx=canvas.getContext('2d');
            ctx.fillStyle='#FFFFFF';
            ctx.fillRect(0,0,70,27);
            ctx.font="20px arial";
            // 创建渐变
            var gradient=ctx.createLinearGradient(0,0,canvas.width,0);
            gradient.addColorStop("0","magenta");
            gradient.addColorStop("0.5","blue");
            gradient.addColorStop("1.0","red");
            // 用渐变填色
            ctx.strokeStyle=gradient;
            ctx.strokeText(code,5,20);//画布上添加验证码
            $("#yzcode").val(code);//给隐藏域添加code，方便比较验证
        }
    }
    //点击验证码可以更换验证码
    $("#myCanvas").click(function () {
        createCode();
    })

    /*添加按钮评论提交事件*/
    $("#com_addBtn").click(function () {
        if (com_textarea==false||com_qq==false||com_code==false){
            alert("请检查评论内容，QQ和验证码");
            return;
        }
        var pid=$("#pid_span").text();//文章的id
        var pqq=$("#com_getqq").val();//评论者的QQ
        var pping=$("#addcom_div_area").text();//评论内容
        var pdate=getTimestamp();//提交评论的时间戳
        var pip= $("#tip_ip").text();//获取评论者ip
        $.ajax({
            url:"/postscom/addCom",
            type:"get",
            /*data向后台传参*/
            data:{
                "pid":pid,
                "pCqq":pqq,
                "pCping":pping,
                "pCdate":pdate,
                "pCip":pip
            },
            //dataType:"json",//这里不需要返回
            success:function (data) {
                alert("评论成功");
                window.location.reload();
            },
            error:function () {
                alert("评论失败");
            }
        })
    })

    //获取作者名字
    function getUnickname(uid){
        var unickname;
        $.ajax({
            url:"/user/getUser",
            type:"get",
            async : false,
            /*data向后台传参*/
            data:"uid="+uid,
            dataType:"json",
            success:function (data) {
                //$(".posts_unickname").html(data.unickname);
                // return data.unickname;
                unickname=data.unickname;
            }
        });
        return unickname;
    }
    /*该函数利用ajax根据classid获取文章分类名称*/
    function getClassifyName(classid){
        var classifyName;
        $.ajax({
            url:"/classify/getClassify",
            type:"get",
            //改为同步请求，否则会返回undefined;
            async : false,
            /*data向后台传参*/
            data:"classid="+classid,
            dataType:"json",
            success:function (data) {
                // alert(data.classname);
                classifyName=data.classname;
            }
        });
        return classifyName;
    }
    /*获取basePath*/
    function basePath(){
        //获取当前网址，如： http://localhost:8080/ems/Pages/Basic/Person.jsp
        var curWwwPath = window.document.location.href;
        //获取主机地址之后的目录，如： /ems/Pages/Basic/Person.jsp
        var pathName = window.document.location.pathname;
        var pos = curWwwPath.indexOf(pathName);
        //获取主机地址，如： http://localhost:8080
        var localhostPath = curWwwPath.substring(0, pos);
        //获取带"/"的项目名，如：/ems
        var projectName = pathName.substring(0, pathName.substr(1).indexOf('/') + 1);
        //获取项目的basePath   http://localhost:8080/ems/
        //var basePath=localhostPath+projectName+"/";
        var basePath=localhostPath
        return basePath;
    };
    //获取时间戳，往数据库添加时用得到
    function getTimestamp(){
        var time=new Date();
        var year=time.getFullYear();
        var month=time.getMonth()+1;
        var day=time.getDate();
        var hour=time.getHours();
        var minu=time.getMinutes();
        var second=time.getMinutes();
        return(year+"-"+month+"-"+day+" "+hour+":"+minu+":"+second);
    }

    /*根据QQ返回头像地址*/
    function getQQimgurl(qq) {
        var qqimgurl;
        $.ajax({
            url:"/qq/getqqInfo",
            type:"get",
            data:"qq="+qq,
            //改为同步请求，否则会返回undefined;
            async : false,
            datatype:"json",
            success:function (data) {
                if (data){
                    qqimgurl=data.imgurl;
                }
            }
        })
        return qqimgurl;
    }
    /*根据QQ返回name*/
    function getQQname(qq) {
        var qqname;
        $.ajax({
            url:"/qq/getqqInfo",
            type:"get",
            data:"qq="+qq,
            //改为同步请求，否则会返回undefined;
            async : false,
            datatype:"json",
            success:function (data) {
                if (data){
                    qqname = data.name;
                }
            }
        })
        return qqname;
    }

    /*根据IP返回地址信息*/
    //后台API失效了，这个用不了
    function getIPaddress1(ip) {
        var ipaddress;
        $.ajax({
            url:"/ip/getIPAddress",
            type:"get",
            data:"ip="+ip,
            //改为同步请求，否则会返回undefined;
            async : false,
            datatype:"json",
            success:function (data) {

                if (data){
                    //ipaddress= data[2];//因为这里返回的data是一个几个，所以直接用下标
                    //alert(ipaddress);
                    ipaddress=data.data.ad_info.city;
                }
            }
        })
        return ipaddress;
    }
    //前端写法，去掉外面的function即可使用
    function getIPaddress2(ip) {
        var ipaddress;
        $.getScript("http://ip.ws.126.net/ipquery?ip="+ip,function(d){
            //$("#ip2").text(localAddress.province+localAddress.city);
            ipaddress=localAddress.province+localAddress.city;
        });
        alert(ipaddress)//undefined
        return ipaddress;
    }

    /*/!*jonp API的用法*!/
    $.ajax({
        headers:{
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'X-Content-Type-Options': 'nosniff'
        },
        //url:"https://api.qqsuu.cn/api/qq",不支持jsonp
        //url:"http://users.qzone.qq.com/fcg-bin/cgi_get_portrait.fcg",//支持jsonp
        url:"https://r.qzone.qq.com/fcg-bin/cgi_get_portrait.fcg?g_tk=1518561325",
        type:"get",
        data:"uins=82371138",
        //crossDomain: true,
        contentType:"text/html;charset=GBK",
        dataType:"jsonp",
        jsonp: "callback",//传递给请求处理程序或页面的，用以获得jsonp回调函数名的参数名(一般默认为:callback)
        jsonpCallback:"portraitCallBack",//自定义的jsonp回调函数名称，默认为jQuery自动生成的随机函数名，也可以写"?"，jQuery会自动为你处理数据
        success:function (data) {
            console.log(data);
            //alert("进来了")
            //alert(data);
            for(var i in data) {
                alert(i)
                alert(i+":"+data[i]+"----");//循环输出a:1,b:2,etc.
            }
        }
    })
    /!*$.jsonp({
        url:"https://api.qqsuu.cn/api/qq",
        type:"get",
        data:"qq=82371138",
        success: function(data) {
            alert("jinlaile");
        }
    })*!/*/
})