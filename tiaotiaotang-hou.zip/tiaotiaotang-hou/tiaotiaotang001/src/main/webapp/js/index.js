$(function () {
    /*利用ajax根据uid获取到用户昵称,这里我把ajax封装成了一个函数，方便之后的函数进行调用/
    /*async. 默认是 true，即为异步方式，$.ajax执行后，会继续执行ajax后面的脚本，直到服务器端返回数据后，触发$.ajax里的success方法，这时候执行的是两个线程。
　　async 设置为 false，则所有的请求均为同步请求，在没有返回值之前，同步请求将锁住浏览器，用户其它操作必须等待请求完成才可以执行。*/
    function getUnickname(uid){
        var unickname;
        $.ajax({
            url:"/user/getUser",
            type:"get",
            async : false,
            /*data向后台传参*/
            data:"uid="+uid,
            dataType:"json",
            success:function (data) {
                //$(".posts_unickname").html(data.unickname);
                // return data.unickname;
                unickname=data.unickname;
            }
        });
        return unickname;
    }
    /*该函数利用ajax根据classid获取文章分类名称*/
    function getClassifyName(classid){
        var classifyName;
        $.ajax({
            url:"/classify/getClassify",
            type:"get",
            //改为同步请求，否则会返回undefined;
            async : false,
            /*data向后台传参*/
            data:"classid="+classid,
            dataType:"json",
            success:function (data) {
                // alert(data.classname);
                classifyName=data.classname;
            }
        });
        return classifyName;
    }

    /*利用ajax获取所有的贴子，正序所有*/
    /*$.ajax({
        url:"/posts/getPosts",
        type:"get",
        data:"",
        dataType:"json",
        success:function (data) {
            if(data && data.length > 0) {
                $.each(data, function(i,m){
                    $("#posts_ul").append("<li>" +
                        "<span class='posts_title'>标题："+m.ptitle+"</span><br>" +
                        "<span class='posts_content'>内容："+m.pcontent+"</span><br>" +
                        "<span class='posts_unickname'>作者："+getUnickname(m.uid)+"</span><br>" +
                        "<span class='posts_classify'>分类："+getClassifyName(m.classid)+"</span><br>" +
                        "<span class='posts_date'>发表日期："+m.pdate+"</span></li>");
                })
            }
        }
    })*/
    /*初始化分页以及实现搜索功能进行分页*/
    $(function () {
        do_page();
        $("#search_btn").click(function () {
            do_page(1);
        })
    })
    function do_page(pageNo) {
        var searchPtitle=$("#search_posts_text").val().trim();
        $.ajax({
            url:"/posts/getPostsByPage",
            type:"get",
            data:{"pageNum":pageNo,"ptitle":searchPtitle},
            dataType:"json",
            success:function (data) {

                if (data.list){
                    //alert("有数据")
                    $("#posts_ul").empty();
                    //var list=data.list;获取返回的list集合
                    var pageNum=data.pageNum;//获取当前页数
                    var totalPages=data.pages;//获取总页数
                    $.each(data.list,function (i,m) {
                        $("#posts_ul").append("<a href='posts/aPosts?pid="+m.pid+"'><li>" +
                            "<img src='../images/system/ttt-logo.png'>" +
                            "<span class='posts_title'>标题："+m.ptitle+"</span><br>" +
                            "<span class='posts_content'>内容："+m.pcontent+"</span><br>" +
                            "<span class='posts_unickname'>作者："+getUnickname(m.uid)+"</span><br>" +
                            "<span class='posts_classify'>分类："+getClassifyName(m.classid)+"</span><br>" +
                            "<span class='posts_date'>发表日期："+m.pdate+"</span></li></a>");
                    })
                }
                /*分页控制*/
                /*在index页面可以直接这么写，封装js后存在作用域的问题，会显示do_page未定义的错误
                $("#posts_pageCon a:eq(0)").attr("href","javascript:do_page(1)");
                $("#posts_pageCon a:eq(1)").attr("href","javascript:do_page("+(pageNum-1)+")");
                $("#posts_pageCon a:eq(2)").attr("href","javascript:do_page("+(pageNum+1)+")");
                $("#posts_pageCon a:eq(3)").attr("href","javascript:do_page("+totalPages+")");*/
                $("#posts_pageCon a:eq(0)").attr("href","javascript:").click(function () {
                    do_page(1)
                });
                $("#posts_pageCon a:eq(1)").attr("href","javascript:").click(function () {
                    pageNum--;//单独写出可避免页面加载慢造成的闪烁
                    do_page(pageNum);
                });
                $("#posts_pageCon a:eq(2)").attr("href","javascript:").click(function () {
                    pageNum++;
                    do_page(pageNum)
                });
                $("#posts_pageCon a:eq(3)").attr("href","javascript:").click(function () {
                    do_page(totalPages);
                })
                //当前页和总页数的显示
                $("#pg").html(pageNum+"/"+totalPages+"页");
                /*利用pagInfo返回的总页数控制搜索结果为空时返回主页*/
                if(totalPages==0){
                    alert("没有获取到List数据,返回主页");
                    window.location.reload();
                }
            }
        })
    }
})

