$(function () {
    /*控制文章分类的二级菜单,通过mouseenter，父元素会出现闪烁问题，动画没加载完就又加载一遍悬浮事件*/
    $("#nav_menu_li").mouseenter(function(){
        /*向下显示，向上隐藏*/
        $("#nav_menu_er").slideDown();
    }).mouseleave(function(){
        $("#nav_menu_er").slideUp();
    })
    /*利用ajax拿到主题分类classify*/
    $.ajax({
        url:"/classify/getAllClassify",
        type:"get",
        data:"",
        dataType:"json",
        success:function (data) {
            if(data && data.length > 0) {
                $.each(data, function(i,m){
                    //alert(m.classname);
                    $("#nav_menu_er").append("<a href='/posts/PostsClassify?classid="+m.classid+"'><li>"+m.classname+"</li></a>");
                })
            }
        }
    })

})