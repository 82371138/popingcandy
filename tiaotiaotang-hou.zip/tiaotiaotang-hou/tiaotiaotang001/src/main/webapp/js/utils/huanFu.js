$(function () {
    var i=0;
    $("#huanpi").click(function () {
        i++;
        if (i>0){
            $("#pifu").attr("class","baipi");
            i=-1;
            return;
        }else {
            $("#pifu").attr("class","heipi");
            return;
        }
    })
})