package com.java.mapper;

import com.java.pojo.Classify;
import tk.mybatis.mapper.common.Mapper;

public interface ClassifyMapper extends Mapper<Classify> {
}