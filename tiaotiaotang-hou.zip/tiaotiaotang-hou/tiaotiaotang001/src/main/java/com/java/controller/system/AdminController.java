package com.java.controller.system;

import com.java.pojo.Admin;
import com.java.pojo.RespBean;
import com.java.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    /**访问admin页面时先跳转到admin登陆页面*/
    @RequestMapping()
    public String adminLoginJsp(HttpSession session){
        //如果session存在，那么就不需要再次输入账号密码，直接进入admin控制页
        if(session.getAttribute("admin_name")!=null){
            return "system/adminContro";
        }
        return "system/adminLogin";
    }
    @RequestMapping("/login")
    public String adminLogin(Admin admin, Model model, HttpSession session){
        model.addAttribute("admin_name",admin.getAname());
        int i =adminService.adminLogin(admin);
        if (i>0){
            session.setAttribute("admin_name",admin.getAname());
            session.setMaxInactiveInterval(3600);//设置session过期时间，1小时
            return "system/adminContro";
        }else {
            model.addAttribute("adminLoginMsg","你的账号账号密码哪个有错，你再试试吧");
            return "system/adminLogin";
        }
    }

    /**admin账户操作，先跳转页面，后实现功能*/
    @RequestMapping("/updateAdmin")
    public String updateAdmin(){return "content/adminUpdate";}
    //功能实现
    @RequestMapping("/updatePwd")
    public String updatePwd(Admin admin,Model model){
        System.out.println(admin.getAname());
        int i=adminService.updatePwd(admin);
        System.out.println(i);
        if (i>0){
            model.addAttribute("updateAdminPwdMsg","修改成功");
            return "content/ModelMsg";
        }else {
            model.addAttribute("updateAdminPwdMsg","修改失败");
            return "content/ModelMsg";
        }
    }

    /**关于页面*/
    @RequestMapping("/about")
    public String abput(){
        return "system/about";
    }
}
