package com.java.service;

import com.github.pagehelper.PageInfo;
import com.java.pojo.Posts;

import java.util.List;
import java.util.Map;

public interface PostsService {
    /**获取所有的贴子并展示所有，正序*/
    public List<Posts> getPostsList();

    /**根据pid倒序查询显示所有的贴子*/
    public List<Posts> getPostsListDesc();

    /**根据pid倒序分页显示，可以根据ptitle进行模糊搜索*/
    public PageInfo<Posts> getPostsListByPage(Integer pageNum, Integer pageSize, Map<String,Object> map) throws RuntimeException;

    /**根据对象插入*/
    public int addPosts(Posts posts);

    /**根据classid进行分页查询显示，主要用于postsByClassify.jsp*/
    public PageInfo<Posts> getPostsByClassid(Integer pageNum, Integer pageSize,Integer classid);

    /**根据pid返回一个Posts对象*/
    public Posts getPostsByPid(Integer pid);

    /**根据pid删除文章*/
    public int deletePostsByPid(Integer pid);

    /**修改文章*/
    public int updatePosts(Posts posts);
}
