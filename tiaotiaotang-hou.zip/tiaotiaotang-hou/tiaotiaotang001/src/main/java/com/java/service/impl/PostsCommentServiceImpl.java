package com.java.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.java.mapper.PostsCommentMapper;
import com.java.pojo.Posts;
import com.java.pojo.PostsComment;
import com.java.service.PostsCommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.List;
@Service
@Transactional
public class PostsCommentServiceImpl implements PostsCommentService {
    @Autowired
    private PostsCommentMapper postsCommentMapper;
    @Override
    public List<PostsComment> getPostsComList(Integer pid) {
        //构建条件查询容器
        Example example=new Example(Posts.class);
        Example.Criteria criteria = example.createCriteria();//每一个criteria都相当于一个括号
        criteria.andEqualTo("pid",pid);
        List<PostsComment> postsComments=postsCommentMapper.selectByExample(example);
        return postsComments;
    }

    @Override
    public int addPostsCom(PostsComment postsComment) {
        int i = postsCommentMapper.insert(postsComment);
        return i;
    }

    @Override
    public int deletePsComBYPid(Integer pid) {
        //构建条件查询容器
        Example example=new Example(Posts.class);
        Example.Criteria criteria = example.createCriteria();//每一个criteria都相当于一个括号
        //设置查询条件where pid=?
        criteria.andEqualTo("pid",pid);
        int i=postsCommentMapper.deleteByExample(example);
        //System.out.println("这是comImpl层的i"+i);
        return i;
    }

    @Override
    public PageInfo<PostsComment> getComByPage(Integer pageNum, Integer pageSize, Integer pid) {
        //构建条件查询容器
        Example example=new Example(PostsComment.class);
        Example.Criteria criteria = example.createCriteria();//每一个criteria都相当于一个括号
        PageHelper.startPage(pageNum,pageSize);
        //设置查询条件where classid=?
        criteria.andEqualTo("pid",pid);
        List<PostsComment> postsComments=postsCommentMapper.selectByExample(example);
        PageInfo<PostsComment> pageInfo=new PageInfo<>(postsComments);
        return pageInfo;
    }

    @Override
    public PageInfo<PostsComment> getAllCom(Integer pageNum, Integer pageSize) {
        //构建条件查询容器
        Example example=new Example(PostsComment.class);
        Example.Criteria criteria = example.createCriteria();
        //根据pid设置倒序查询
        example.setOrderByClause("p_cid desc");
        PageHelper.startPage(pageNum,pageSize);
        List<PostsComment> postsComments=postsCommentMapper.selectByExample(example);
        PageInfo<PostsComment> pageInfo=new PageInfo<>(postsComments);
        return pageInfo;
    }

    @Override
    public int deleteComByPCid(Integer pcid) {
        int i=postsCommentMapper.deleteByPrimaryKey(pcid);
        return i;
    }

}
