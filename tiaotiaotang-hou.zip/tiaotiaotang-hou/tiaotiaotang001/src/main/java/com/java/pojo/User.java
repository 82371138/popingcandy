package com.java.pojo;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import javax.persistence.*;

@Table(name = "ttt_user")
public class User {
    @Id
    @GeneratedValue(generator = "JDBC")
    private Integer uid;

    private String uname;

    private String upwd;

    private String uimg;
    //@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private String udate;

    private Integer uqq;

    private String unickname;

    /**
     * @return uid
     */
    public Integer getUid() {
        return uid;
    }

    /**
     * @param uid
     */
    public void setUid(Integer uid) {
        this.uid = uid;
    }

    /**
     * @return uname
     */
    public String getUname() {
        return uname;
    }

    /**
     * @param uname
     */
    public void setUname(String uname) {
        this.uname = uname;
    }

    /**
     * @return upwd
     */
    public String getUpwd() {
        return upwd;
    }

    /**
     * @param upwd
     */
    public void setUpwd(String upwd) {
        this.upwd = upwd;
    }

    /**
     * @return uimg
     */
    public String getUimg() {
        return uimg;
    }

    /**
     * @param uimg
     */
    public void setUimg(String uimg) {
        this.uimg = uimg;
    }

    /**
     * @return udate
     */
    public String getUdate() {
        return udate;
    }

    /**
     * @param udate
     */
    public void setUdate(String udate) {
        this.udate = udate;
    }

    /**
     * @return uqq
     */
    public Integer getUqq() {
        return uqq;
    }

    /**
     * @param uqq
     */
    public void setUqq(Integer uqq) {
        this.uqq = uqq;
    }

    /**
     * @return unickname
     */
    public String getUnickname() {
        return unickname;
    }

    /**
     * @param unickname
     */
    public void setUnickname(String unickname) {
        this.unickname = unickname;
    }
}