package com.java.service;

import com.java.pojo.PostsImages;

import java.util.List;

public interface PostsImagesService {
    /**根据PostsImage对象进行插入*/
    public int addPsImage(PostsImages postsImages);

    /**根据pid返回postsImages集合，用于显示详情*/
    public List<PostsImages> getPostsImagesByPid(Integer pid);

    /**根据pid删除所有图片对应的地址*/
    public int deletePsImgByPid (Integer pid);

    /**根据imgid删除单张图片地址*/
    public int deleteAImgByImgid(Integer imgid);

    /**查询文件路径中的图片是否存在数据库中，没有则是冗余图片*/
    public boolean cleanPsImg(String imgname);
}
