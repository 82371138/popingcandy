package com.java.service;

import com.java.pojo.Admin;

public interface AdminService {
    /**登陆查询*/
    public int adminLogin(Admin admin);

    /**修改密码*/
    public int updatePwd(Admin admin);
}
