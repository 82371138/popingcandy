package com.java.mapper;

import com.java.pojo.PostsImages;
import tk.mybatis.mapper.common.Mapper;

public interface PostsImagesMapper extends Mapper<PostsImages> {
}