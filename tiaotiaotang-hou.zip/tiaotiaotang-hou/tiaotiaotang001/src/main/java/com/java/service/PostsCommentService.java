package com.java.service;

import com.github.pagehelper.PageInfo;
import com.java.pojo.PostsComment;

import java.util.List;

public interface PostsCommentService {
    /**根据pid返回评论集合*/
    public List<PostsComment> getPostsComList(Integer pid);

    /**根据postsComment添加评论*/
    public int addPostsCom(PostsComment postsComment);

    /**根据pid删除所有评论*/
    public int deletePsComBYPid(Integer pid);

    /**分页查询评论单个文章内的评论*/
    public PageInfo<PostsComment> getComByPage(Integer pageNum, Integer pageSize,Integer pid);

    /**获取所有的评论，admin操作,根据主键进行倒序查询*/
    public PageInfo<PostsComment> getAllCom(Integer pageNum, Integer pageSize);

    /**根据p_cid删除单个评论*/
    public int deleteComByPCid(Integer pcid);
}
