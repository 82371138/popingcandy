package com.java.mapper;

import com.java.pojo.Posts;
import tk.mybatis.mapper.common.Mapper;

public interface PostsMapper extends Mapper<Posts> {
}