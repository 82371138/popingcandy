package com.java.controller.content;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

@RestController
@RequestMapping("/ip")
public class IPAPIController {
    /**返回本地ip信息*/
    @RequestMapping(value = "/getIPInfo",produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String getIPinfo(){
        StringBuilder jsonString = new StringBuilder();
        URLConnection connection = null;
        try {
            URL urlObject = new URL("https://v1.alapi.cn/api/ip");
            connection = urlObject.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(),"utf-8"));
            String inputLine = null;
            while ((inputLine = in.readLine()) != null) {
                jsonString.append(inputLine);
            }
            in.close();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //接口1返回的数据带有portraitCallBack函数，所以要进行字符串截取，这种带callback参数的前端可以直接用ajax获取
        //return jsonString.toString().substring("portraitCallBack(".length(),jsonString.length()-1);
        return jsonString.toString();
    }
    /**根据ip返回地址信息*/
    @RequestMapping(value = "/getIPAddress",produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String getIPAddress(@RequestParam("ip")String ip){
        StringBuilder jsonString = new StringBuilder();
        URLConnection connection = null;
        try {
            URL urlObject = new URL("https://v1.alapi.cn/api/ip?ip="+ip);
            connection = urlObject.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(),"utf-8"));
            String inputLine = null;
            while ((inputLine = in.readLine()) != null) {
                jsonString.append(inputLine);
            }
            in.close();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return jsonString.toString();
    }
}
