package com.java.pojo;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import javax.persistence.*;

@Table(name = "ttt_posts")
public class Posts {
    @Id
    @GeneratedValue(generator = "JDBC")
    private Integer pid;

    private Integer uid;

    private Integer classid;

    private String pip;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private String pdate;

    private String ptitle;

    private String pcontent;

    /**
     * @return pid
     */
    public Integer getPid() {
        return pid;
    }

    /**
     * @param pid
     */
    public void setPid(Integer pid) {
        this.pid = pid;
    }

    /**
     * @return uid
     */
    public Integer getUid() {
        return uid;
    }

    /**
     * @param uid
     */
    public void setUid(Integer uid) {
        this.uid = uid;
    }

    /**
     * @return classid
     */
    public Integer getClassid() {
        return classid;
    }

    /**
     * @param classid
     */
    public void setClassid(Integer classid) {
        this.classid = classid;
    }

    /**
     * @return pip
     */
    public String getPip() {
        return pip;
    }

    /**
     * @param pip
     */
    public void setPip(String pip) {
        this.pip = pip;
    }

    /**
     * @return pdate
     */
    public String getPdate() {
        return pdate;
    }

    /**
     * @param pdate
     */
    public void setPdate(String pdate) {
        this.pdate = pdate;
    }

    /**
     * @return ptitle
     */
    public String getPtitle() {
        return ptitle;
    }

    /**
     * @param ptitle
     */
    public void setPtitle(String ptitle) {
        this.ptitle = ptitle;
    }

    /**
     * @return pcontent
     */
    public String getPcontent() {
        return pcontent;
    }

    /**
     * @param pcontent
     */
    public void setPcontent(String pcontent) {
        this.pcontent = pcontent;
    }
}