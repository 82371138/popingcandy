package com.java.mapper;

import com.java.pojo.PostsComment;
import tk.mybatis.mapper.common.Mapper;

public interface PostsCommentMapper extends Mapper<PostsComment> {
}