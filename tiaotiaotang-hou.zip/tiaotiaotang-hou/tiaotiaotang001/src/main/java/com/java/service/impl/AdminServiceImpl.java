package com.java.service.impl;

import com.java.mapper.AdminMapper;
import com.java.pojo.Admin;
import com.java.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

@Service
@Transactional
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AdminMapper adminMapper;
    @Override
    public int adminLogin(Admin admin) {
        //构建条件查询容器
        Example example=new Example(Admin.class);
        Example.Criteria criteria = example.createCriteria();
        /*本来想着用where aname=? and apwd=?进行查询，mybatis自带的有根据pojo实体类查询，就没用了
        criteria.andEqualTo("aname",admin.getAname()).andEqualTo("apwd",admin.getApwd());*/
        int i=adminMapper.selectCount(admin);
        return i;
    }

    @Override
    public int updatePwd(Admin admin) {
        int i=adminMapper.updateByPrimaryKey(admin);
        return i;
    }
}
