package com.java.service.impl;

import com.java.mapper.PostsImagesMapper;
import com.java.pojo.Posts;
import com.java.pojo.PostsImages;
import com.java.service.PostsImagesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.List;

@Service
@Transactional
public class PostsImagesServiceImpl implements PostsImagesService {
    @Autowired
    private PostsImagesMapper postsImagesMapper;

    @Override
    public int addPsImage(PostsImages postsImages) {
        int i = postsImagesMapper.insert(postsImages);
        return i;
    }

    @Override
    public List<PostsImages> getPostsImagesByPid(Integer pid) {
        //构建条件查询容器
        Example example=new Example(Posts.class);
        Example.Criteria criteria = example.createCriteria();//每一个criteria都相当于一个括号
        criteria.andEqualTo("pid",pid);
        List<PostsImages> postsImagesList=postsImagesMapper.selectByExample(example);
        return postsImagesList;
    }

    @Override
    public int deletePsImgByPid(Integer pid) {
        //构建条件查询容器
        Example example=new Example(Posts.class);
        Example.Criteria criteria = example.createCriteria();//每一个criteria都相当于一个括号
        //设置查询条件where pid=?
        criteria.andEqualTo("pid",pid);
        int i = postsImagesMapper.deleteByExample(example);
        //System.out.println("这是imgImpl层的i"+i);
        return i;
    }

    @Override
    public int deleteAImgByImgid(Integer imgid) {
        //构建条件查询容器
        Example example=new Example(PostsImages.class);
        Example.Criteria criteria = example.createCriteria();//每一个criteria都相当于一个括号
        //设置查询条件where imgid=?
        criteria.andEqualTo("imgid",imgid);
        int i=postsImagesMapper.deleteByExample(example);
        System.out.println("这是删除单个图片地址的impl层的i"+i);
        return i;
    }

    @Override
    public boolean cleanPsImg(String imgname) {
        //构建条件查询容器
        Example example=new Example(PostsImages.class);
        Example.Criteria criteria = example.createCriteria();//每一个criteria都相当于一个括号
        criteria.andEqualTo("imgurl",imgname);
        int i =postsImagesMapper.selectCountByExample(example);//根据图片name查询返回条数
        //System.out.println("这是cleanPsImgImpl层的i"+i);
        if (i>0){
            return true;
        }else {
            return false;
        }
    }
}
