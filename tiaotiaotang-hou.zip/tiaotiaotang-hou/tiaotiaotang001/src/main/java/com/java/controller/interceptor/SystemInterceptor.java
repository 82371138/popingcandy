package com.java.controller.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SystemInterceptor implements HandlerInterceptor {
    /**
     * 在进入Handler方法执行之前执行本方法
     *
     * @return true:执行下一个拦截器，直到所有拦截器都执行完，再执行被拦截的Controller
     *         false:从当前的拦截器往回执行所有拦截器的afterCompletion(),再退出拦截器链
     */
    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o) throws Exception {
        httpServletRequest.setCharacterEncoding("UTF-8");
        httpServletResponse.setContentType("application/json;charset=UTF-8");
        //设置跨域请求
        /*httpServletResponse.setHeader("Access-Control-Allow-Origin","*");
        httpServletResponse.setHeader("Cache-Control","no-cache");
        httpServletResponse.setHeader("Access-Control-Allow-Methods","POST, GET");
        httpServletResponse.setHeader("Access-Control-Allow-Headers","x-requested-with,content-type");*/
        httpServletResponse.setHeader("Access-Control-Allow-Origin", "origin");
        httpServletResponse.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
        httpServletResponse.setHeader("Access-Control-Max-Age", "3600");
        httpServletResponse.setHeader("Access-Control-Allow-Headers", "x-requested-with,Authorization,token, content-type"); //这里要加上content-type
        httpServletResponse.setHeader("Access-Control-Allow-Credentials", "true");

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {

    }
}
