package com.java.controller.content;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

@Controller
@RequestMapping("/qq")
public class QQAPIController {
    /**根据qqAPI返回QQ头像地址和QQ昵称*/
    @RequestMapping(value = "/getqqInfo",produces = "application/json;charset=UTF-8")//设置返回前端编码格式
    @ResponseBody
    public String getqqinfo(@RequestParam("qq") Integer qq){
        StringBuilder jsonString = new StringBuilder();
        URLConnection connection = null;
        try {
            //1.gbk编码，qq空间接口，获取到的头像是QQ空间的，但名字是正常资料的,带有callback，要进行字符串截取
            //URL urlObject = new URL("https://r.qzone.qq.com/fcg-bin/cgi_get_portrait.fcg?g_tk=1518561325&uins="+qq);
            //2.utf-8，第三方的接口，返回正常QQ资料的头像和名字
            //URL urlObject = new URL("https://jiekou.ouliweb.cn/api/qqxt/api.php?qq="+qq);
            //3.utf-8,也是第三方接口,稳定些，返回正常QQ资料的头像和名字
            URL urlObject = new URL("https://api.qqsuu.cn/api/qq?qq="+qq);
            connection = urlObject.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(),"utf-8"));
            String inputLine = null;
            while ((inputLine = in.readLine()) != null) {
                jsonString.append(inputLine);
            }
            in.close();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //接口1返回的数据带有portraitCallBack函数，所以要进行字符串截取，这种带callback参数的前端可以直接用ajax获取
        //return jsonString.toString().substring("portraitCallBack(".length(),jsonString.length()-1);
        return jsonString.toString();
    }
    /*这是接口1对应的根据API返回的json数据，先是JSONArray
    public static QQ getQQInfo(Long qqId) {
        QQ qq = new QQ();
        String jsonString = getQQJsonStr(qqId);
        JSONObject jsonObject = JSON.parseObject(jsonString);
        JSONArray jsonArray = jsonObject.getJSONArray(String.valueOf(qqId));
        qq.setId(qqId);
        qq.setName((String) jsonArray.get(6));
        qq.setAvatar((String) jsonArray.get(0));
        return qq;
    }
    public static void main(String args[]) {
        System.out.println(getQQInfo(847064370L));
    }*/
}
