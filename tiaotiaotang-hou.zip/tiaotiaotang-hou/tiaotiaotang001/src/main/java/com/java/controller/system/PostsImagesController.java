package com.java.controller.system;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.java.pojo.PostsImages;
import com.java.pojo.RespBean;
import com.java.service.PostsImagesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("/postsimg")
public class PostsImagesController {
    @Autowired
    private PostsImagesService postsImagesService;

    /**ajax上传图片,返回图片上传后生成的文件名*/
    @PostMapping(value = "/upload_ajax",produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String upload_ajax(MultipartFile pic, HttpServletRequest request){
        //1、获得上传文件夹的真实路径（是文件在tomcat服务上的路径）
        String realPath=request.getSession().getServletContext().getRealPath("/images/posts/");
        //System.out.println(realPath);
        //2、如果上传的文件夹不存在就创建
        File realPathFolder=new File(realPath);
        if(!realPathFolder.exists()){
            realPathFolder.mkdirs();
        }
        //3、上传文件的原始文件名
        String oldName=pic.getOriginalFilename();
        //4、创建新文件名，防止上传的文件同名覆盖之前上传的文件
        String newName= UUID.randomUUID().toString()+oldName.substring(oldName.lastIndexOf("."),oldName.length());
        try {
            pic.transferTo(new File(realPath,newName));

            //返回资源的路径 http://localhost:8080/
            // String filePath=request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+ "/uploadFile/"+ newName;
            //后端的String转成json
            ObjectMapper mapper=new ObjectMapper();
            String json_picname = mapper.writeValueAsString(newName);
            //System.out.println(json_picname);
            return json_picname;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**根据pid返回图片地址集合*/
    @RequestMapping("/getImgList")
    @ResponseBody
    public List<PostsImages> getImgList(@RequestParam(name = "pid") Integer pid){
        List<PostsImages> postsImagesList=postsImagesService.getPostsImagesByPid(pid);
        return postsImagesList;
    }

    /**根据imgid删除单张图片地址*/
    @RequestMapping(value = "/deleteAimgurl/{imgid}",produces = "application/json;charset=UTF-8")//设置返回编码格式
    @ResponseBody
    public RespBean deleteAimgurl(@PathVariable Integer imgid){
        int i=postsImagesService.deleteAImgByImgid(imgid);
        //这里只用判断posts返回的值就OK了，因为数据库有关联约束，如果img和com有数据且没删除成功，那么posts也删不掉
        if (i>0){
            return RespBean.ok("删除成功");
        }else {
            return RespBean.error("删除失败");
        }
    }
    @RequestMapping(value = "/addAimg",produces = "application/json;charset=UTF-8")//设置返回编码格式
    @ResponseBody
    public RespBean addAimg(PostsImages postsImages){
        int i=postsImagesService.addPsImage(postsImages);
        if (i>0){
            return RespBean.ok("上传成功");
        }else {
            return RespBean.error("上传失败");
        }
    }

    /**删除冗余图片images/posts/img*/
    @RequestMapping("/clean")
    public String clean(){return "content/cleanPostsImg";}
    @RequestMapping(value = "/cleanPostsImg",produces = "application/json;charset=UTF-8")
    @ResponseBody
    public RespBean cleanPostsImg(HttpServletRequest request){
        int totalCont=0;//记录删除总条数
        //1、获得上传文件夹的真实路径（是文件在tomcat服务上的路径）
        String realPath=request.getSession().getServletContext().getRealPath("/images/posts/");
        //2.创建要遍历文件的文件夹
        File folder=new File(realPath);
        //3.获取到该文件夹下所有的文件
        File[] files=folder.listFiles();
        if (files!=null){
            for (File f:files
                 ) {
                //4.用文件名对比数据库中的imgurl
                boolean cunzai=postsImagesService.cleanPsImg(f.getName());
                //5.如果数据库中没有就删除;
                if (!cunzai){
                    totalCont++;
                    f.delete();
                }
            }
        }
        return RespBean.ok("删除数量：",totalCont);
    }
}
