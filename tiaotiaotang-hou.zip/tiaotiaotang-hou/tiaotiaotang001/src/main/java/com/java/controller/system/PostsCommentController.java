package com.java.controller.system;

import com.github.pagehelper.PageInfo;
import com.java.pojo.PostsComment;
import com.java.pojo.RespBean;
import com.java.service.PostsCommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/postscom")
public class PostsCommentController {
    @Autowired
    private PostsCommentService postsCommentService;

    /**
     * 根据pid返回评论集合
     */
    @RequestMapping("/getComList")
    @ResponseBody
    public List<PostsComment> getComList(@RequestParam(name = "pid") Integer pid) {
        List<PostsComment> postsComments = postsCommentService.getPostsComList(pid);
        return postsComments;
    }

    /**
     * 添加评论
     */
    @RequestMapping("/addCom")
    public String addCom(PostsComment postsComment, Model model) {
        int i = postsCommentService.addPostsCom(postsComment);
        System.out.println(i);
        if (i > 0) {
            model.addAttribute("addComMsg", "评论成功");
        } else {
            model.addAttribute("addComMsg", "评论成功");
        }
        return "system/aPosts";
    }

    /**
     * 根据pid进行分页返回评论
     */
    @RequestMapping("/getComListByPage")
    @ResponseBody
    public PageInfo<PostsComment> getComListByPage(@RequestParam(name = "pageNum", defaultValue = "1") Integer pageNum,
                                                   @RequestParam(name = "pageSize", defaultValue = "5") Integer pageSize,
                                                   @RequestParam(name = "pid") Integer pid) {
        PageInfo<PostsComment> pageInfo = postsCommentService.getComByPage(pageNum, pageSize, pid);
        return pageInfo;
    }

    /**
     * 对所有评论进行操作
     */
    @RequestMapping("/postsComOperate")
    public String postsComOperate() {
        return "content/postsComOperate";
    }

    @RequestMapping("/getAllComByPage")
    @ResponseBody
    public PageInfo<PostsComment> getAllComByPage(@RequestParam(name = "pageNum", defaultValue = "1") Integer pageNum,
                                                  @RequestParam(name = "pageSize", defaultValue = "7") Integer pageSize) {
        PageInfo<PostsComment> pageInfo = postsCommentService.getAllCom(pageNum, pageSize);
        return pageInfo;
    }

    //删除功能
    @DeleteMapping(value = "/deleteCom/{pcid}", produces = "application/json;charset=UTF-8")//设置返回编码格式
    @ResponseBody
    public RespBean deleteCom(@PathVariable Integer pcid) {
        int i = postsCommentService.deleteComByPCid(pcid);
        if (i > 0) {
            return RespBean.ok("删除成功");
        } else {
            return RespBean.error("删除失败");
        }
    }
}