package com.java.service.impl;

import com.java.mapper.ClassifyMapper;
import com.java.pojo.Classify;
import com.java.service.ClassifyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ClassifyServiceImpl implements ClassifyService {
    @Autowired
    private ClassifyMapper classifyMapper;
    @Override
    public List<Classify> getClassifys() {
        List<Classify> classifyList=classifyMapper.selectAll();
        return classifyList;
    }

    @Override
    public Classify getClassifyById(Integer classid) {
        Classify classify=classifyMapper.selectByPrimaryKey(classid);
        return classify;
    }

    @Override
    public int addClassify(Classify classify) {
        int i=classifyMapper.insert(classify);
        return i;
    }

    @Override
    public int updateClassify(Classify classify) {
        int i=classifyMapper.updateByPrimaryKey(classify);

        return i;
    }

    @Override
    public int deleteClassify(Integer classid) {
        int i=classifyMapper.deleteByPrimaryKey(classid);
        return i;
    }
}
