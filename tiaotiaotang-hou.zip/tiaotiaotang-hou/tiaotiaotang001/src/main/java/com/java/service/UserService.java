package com.java.service;

import com.java.pojo.User;

import java.util.List;

public interface UserService {
    /**获取到所有用户的信息*/
    public List<User> getUsers();

    /**根据uid获取到一个User对象*/
    public User getUserById(Integer uid);
}
