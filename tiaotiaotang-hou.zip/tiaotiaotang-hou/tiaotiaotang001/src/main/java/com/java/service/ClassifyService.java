package com.java.service;

import com.java.pojo.Classify;

import java.util.List;

public interface ClassifyService {
    /**获取所有的文章分类，用于生成导航栏二级菜单*/
    public List<Classify> getClassifys();

    /**根据classid获取当前文章分类名称*/
    public Classify getClassifyById(Integer classid);

    /**添加一个classify*/
    public int addClassify(Classify classify);

    /**修改文章分类name*/
    public int updateClassify(Classify classify);

    /**根据classid删除单个文章分类classify*/
    public int deleteClassify(Integer classid);
}
