package com.java.pojo;

import javax.persistence.*;

@Table(name = "ttt_classify")
public class Classify {
    @Id
    @GeneratedValue(generator = "JDBC")
    private Integer classid;

    private String classname;

    /**
     * @return classid
     */
    public Integer getClassid() {
        return classid;
    }

    /**
     * @param classid
     */
    public void setClassid(Integer classid) {
        this.classid = classid;
    }

    /**
     * @return classname
     */
    public String getClassname() {
        return classname;
    }

    /**
     * @param classname
     */
    public void setClassname(String classname) {
        this.classname = classname;
    }
}