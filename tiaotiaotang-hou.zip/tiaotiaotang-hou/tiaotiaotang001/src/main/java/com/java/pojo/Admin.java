package com.java.pojo;

import javax.persistence.*;

@Table(name = "ttt_admin")
public class Admin {
    @Id
    @GeneratedValue(generator = "JDBC")
    private Integer aid;

    private String aname;

    private String apwd;

    /**
     * @return aid
     */
    public Integer getAid() {
        return aid;
    }

    /**
     * @param aid
     */
    public void setAid(Integer aid) {
        this.aid = aid;
    }

    /**
     * @return aname
     */
    public String getAname() {
        return aname;
    }

    /**
     * @param aname
     */
    public void setAname(String aname) {
        this.aname = aname;
    }

    /**
     * @return apwd
     */
    public String getApwd() {
        return apwd;
    }

    /**
     * @param apwd
     */
    public void setApwd(String apwd) {
        this.apwd = apwd;
    }
}