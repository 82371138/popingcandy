package com.java.pojo;

import javax.persistence.*;

@Table(name = "ttt_p_images")
public class PostsImages {
    @Id
    @GeneratedValue(generator = "JDBC")
    private Integer imgid;

    private Integer pid;

    private String imgurl;

    /**
     * @return imgid
     */
    public Integer getImgid() {
        return imgid;
    }

    /**
     * @param imgid
     */
    public void setImgid(Integer imgid) {
        this.imgid = imgid;
    }

    /**
     * @return pid
     */
    public Integer getPid() {
        return pid;
    }

    /**
     * @param pid
     */
    public void setPid(Integer pid) {
        this.pid = pid;
    }

    /**
     * @return imgurl
     */
    public String getImgurl() {
        return imgurl;
    }

    /**
     * @param imgurl
     */
    public void setImgurl(String imgurl) {
        this.imgurl = imgurl;
    }
}