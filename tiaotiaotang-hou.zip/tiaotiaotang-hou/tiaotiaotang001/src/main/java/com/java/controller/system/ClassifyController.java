package com.java.controller.system;

import com.java.pojo.Classify;
import com.java.pojo.RespBean;
import com.java.service.ClassifyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/classify")
public class ClassifyController {
    @Autowired
    private ClassifyService classifyService;
    /**获取到所有的classify*/
    @RequestMapping("/getAllClassify")
    @ResponseBody
    public List<Classify> getAllClassify(){
        List<Classify> classifyList=classifyService.getClassifys();
        return classifyList;
    }

    /**根据classid返回一个cassify的对象*/
    @RequestMapping("getClassify")
    @ResponseBody
    public Classify getClassify(@RequestParam("classid") Integer classid){
        Classify classify=classifyService.getClassifyById(classid);
        return  classify;
    }

    /**classify操作，先跳转到操作页面，再实现功能*/
    @RequestMapping("/classifyOperate")
    public String classifyOperate(Model model){
        List<Classify> classifyList=classifyService.getClassifys();
        model.addAttribute("classifyList",classifyList);
        return "content/classifyOperate";
    }
    //添加功能
    @RequestMapping(value = "/addClassify",produces = "application/json;charset=UTF-8")//设置返回编码格式)
    @ResponseBody
    public RespBean addClassify(Classify classify){
        int i=classifyService.addClassify(classify);
        if (i>0){
            return RespBean.ok("添加成功");
        }else {
            return RespBean.error("添加失败");
        }
    }
    //修改功能
    @RequestMapping(value = "/updateClassify",produces = "application/json;charset=UTF-8")//设置返回编码格式)
    @ResponseBody
    public RespBean updateClassify(Classify classify){
        int i=classifyService.updateClassify(classify);
        if (i>0){
            return RespBean.ok("修改成功");
        }else {
            return RespBean.error("修改失败");
        }
    }
    //删除功能
    @DeleteMapping(value = "/deleteClassify/{classid}",produces = "application/json;charset=UTF-8")//设置返回编码格式
    @ResponseBody
    public RespBean deleteClassify(@PathVariable Integer classid){
        int i = classifyService.deleteClassify(classid);
        if (i>0){
            return RespBean.ok("删除成功");
        }
        return RespBean.error("删除失败");
    }
}
