package com.java.controller.system;

import com.java.pojo.User;
import com.java.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;
    /**
     * 根据前端传入的uid获取user*/
    @RequestMapping("/getUser")
    @ResponseBody
    public User getUser(@RequestParam("uid") Integer uid){
        User user=userService.getUserById(uid);
        //System.out.println(user.getUnickname());
        return user;
    }
    /**获取到所有用户列表*/
    @GetMapping("/getusers")
    public String getalluser(Model model){
        List<User> userList=userService.getUsers();
        model.addAttribute("userList",userList);
        return "content/userList";
    }
}
