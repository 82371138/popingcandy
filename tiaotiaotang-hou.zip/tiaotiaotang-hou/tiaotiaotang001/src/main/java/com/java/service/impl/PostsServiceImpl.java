package com.java.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.java.mapper.PostsMapper;
import com.java.pojo.Posts;
import com.java.service.PostsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.StringUtil;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class PostsServiceImpl implements PostsService {
    @Autowired
    private PostsMapper postsMapper;
    @Override
    public List<Posts> getPostsList() {
        List<Posts> postsList=postsMapper.selectAll();
        return postsList;
    }

    @Override
    public List<Posts> getPostsListDesc() {
        //构建条件查询容器
        Example example=new Example(Posts.class);
        Example.Criteria criteria = example.createCriteria();
        example.setOrderByClause("pid desc");
        //
        List<Posts> postsList = postsMapper.selectByExample(example);
        return postsList;
    }

    @Override
    public PageInfo<Posts> getPostsListByPage(Integer pageNum, Integer pageSize, Map<String, Object> map) throws RuntimeException {
        //构建条件查询容器
        Example example=new Example(Posts.class);
        Example.Criteria criteria = example.createCriteria();
        //根据pid设置倒序查询
        example.setOrderByClause("pid desc");
        if(map!=null&& StringUtil.isNotEmpty(map.get("ptitle").toString().trim())){
            criteria.andLike("ptitle","%"+map.get("ptitle")+"%");
        }
        PageHelper.startPage(pageNum,pageSize);
        List<Posts> postsList = postsMapper.selectByExample(example);
        PageInfo<Posts> pageInfo = new PageInfo<>(postsList);
        return pageInfo;
    }

    @Override
    public int addPosts(Posts posts) {
        int i=postsMapper.insert(posts);
        int pid=posts.getPid();
        //这里我让返回了当前文章的pid，方便后面添加图片的功能实现
        return pid;
    }
    /**根据文章分类进行分页and包含搜索功能*/
    @Override
    public PageInfo<Posts> getPostsByClassid(Integer pageNum, Integer pageSize, Integer classid) {
        //构建条件查询容器
        Example example=new Example(Posts.class);
        Example.Criteria criteria = example.createCriteria();//每一个criteria都相当于一个括号
        //根据pid设置倒序查询
        example.setOrderByClause("pid desc");
        PageHelper.startPage(pageNum,pageSize);
        //设置查询条件where classid=?
        criteria.andEqualTo("classid",classid);
        List<Posts> postsList = postsMapper.selectByExample(example);
        PageInfo<Posts> pageInfo = new PageInfo<>(postsList);
        return pageInfo;
    }

    @Override
    public Posts getPostsByPid(Integer pid) {
        Posts posts=postsMapper.selectByPrimaryKey(pid);
        return posts;
    }

    @Override
    public int deletePostsByPid(Integer pid) {
        //构建条件查询容器
        Example example=new Example(Posts.class);
        Example.Criteria criteria = example.createCriteria();//每一个criteria都相当于一个括号
        //设置查询条件where pid=?
        criteria.andEqualTo("pid",pid);
        int i =postsMapper.deleteByPrimaryKey(pid);
        //System.out.println("这是postsImpl层的i"+i);
        return i;
    }

    @Override
    public int updatePosts(Posts posts) {
        int i=postsMapper.updateByPrimaryKey(posts);
        //System.out.println("这是修改postsImpl层的i"+i);
        return i;
    }
}
