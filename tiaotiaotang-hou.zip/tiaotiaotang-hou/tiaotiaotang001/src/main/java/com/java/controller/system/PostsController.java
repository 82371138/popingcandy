package com.java.controller.system;

import com.github.pagehelper.PageInfo;
import com.java.pojo.Classify;
import com.java.pojo.Posts;
import com.java.pojo.PostsImages;
import com.java.pojo.RespBean;
import com.java.service.ClassifyService;
import com.java.service.PostsCommentService;
import com.java.service.PostsImagesService;
import com.java.service.PostsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/posts")
public class PostsController {
    @Autowired
    private PostsService postsService;
    @Autowired
    private ClassifyService classifyService;
    @Autowired
    private PostsImagesService postsImagesService;
    @Autowired
    private PostsCommentService postsCommentService;

    @RequestMapping("/getPosts")
    @ResponseBody
    public List<Posts> getPosts(){
        List<Posts> postsList=postsService.getPostsList();
        return postsList;
    }

    @RequestMapping("/getPostsDesc")
    @ResponseBody
    public List<Posts> getPostsDesc(){
        List<Posts> postsList=postsService.getPostsListDesc();
        return postsList;
    }
    /**倒序分页查询*/
    @RequestMapping("/getPostsByPage")
    @ResponseBody
    public PageInfo<Posts> getPostsByPage(@RequestParam(name = "pageNum",defaultValue = "1") Integer pageNum,
                                          @RequestParam(name = "pageSize",defaultValue = "3") Integer pageSize,
                                          @RequestParam(name = "ptitle") String ptitle) throws UnsupportedEncodingException {
        Map<String,Object> map=new HashMap<>();
        //ptitle=new String(ptitle.getBytes("ISO-8859-1"),"UTF-8");/*这句加了前台传进来的文字会变问号'？'*/
        map.put("ptitle",ptitle);
        PageInfo<Posts> pageInfo=postsService.getPostsListByPage(pageNum,pageSize,map);
        return pageInfo;
    }

    /**文章分类页，先跳转到页面，后实现功能*/
    @RequestMapping("PostsClassify")
    public String PostsClassify(@RequestParam("classid") Integer classid,Model model){
        Classify classify =classifyService.getClassifyById(classid);
        model.addAttribute("classid",classid);
        model.addAttribute("classname",classify.getClassname());
        return "system/postsByClassify";
    }
    @RequestMapping("getPostsByClassify")
    @ResponseBody
    public PageInfo<Posts> getPostsByClassify(@RequestParam(name = "pageNum",defaultValue = "1") Integer pageNum,
                                              @RequestParam(name = "pageSize",defaultValue = "3") Integer pageSize,
                                              @RequestParam(name = "classid") Integer classid){

        PageInfo<Posts> pageInfo=postsService.getPostsByClassid(pageNum,pageSize,classid);
        return pageInfo;
    }

    /**单个posts详情，先跳转到指定页面，后实现*/
    @RequestMapping("/aPosts")
    public String aPostsJsp(@RequestParam(name = "pid") Integer pid,Model model){
        model.addAttribute("model_pid",pid);
        return "system/aPosts";
    }
    @RequestMapping("/getAPosts")
    @ResponseBody
    public Posts getAPosts(@RequestParam(name = "pid") Integer pid){
        Posts posts=postsService.getPostsByPid(pid);
        return posts;
    }


    /**添加文章,先跳转到页面，后实现功能*/
    @RequestMapping("/addJsp")
    public String addJsp(){
        return "content/addPosts";
    }
    @RequestMapping(value = "/addPosts")//设置返回编码格式
    public String addPosts(Posts posts, Model model,@RequestParam(name = "imgurl") String imgurl){
        int pid =postsService.addPosts(posts);//要这个pid主要是到后面添加图片用的
        //前端传来的是url拼接的字符串，先分割下，看有几个图片地址
        String[] imgurlArray=imgurl.split(";");
        if(imgurlArray!=null){
            for (int i = 0; i <imgurlArray.length ; i++) {
                //先判断是否为空字符串，防止往数据库插入空值
                if (imgurlArray[i].equals("")||imgurlArray[i]==null){
                    break;
                }
                PostsImages p=new PostsImages();
                p.setPid(pid);
                p.setImgurl(imgurlArray[i].toString());
                postsImagesService.addPsImage(p);
            }
        }
        if(pid!=0&&pid>0){
            model.addAttribute("addPostsMsg","添加成功");
            return "content/ModelMsg";
        }else {
            model.addAttribute("addPostsMsg","添加失败");
            return "content/ModelMsg";
        }
    }

    /**先跳转打文章列表，然后进行修改和删除的操作*/
    @RequestMapping("/operateJsp")
    public String operateJsp(){return "content/postsList";};
    @DeleteMapping(value = "/deletePosts/{pid}",produces = "application/json;charset=UTF-8")//设置返回编码格式
    @ResponseBody
    public RespBean deletePosts(@PathVariable Integer pid){
        int com=postsCommentService.deletePsComBYPid(pid);
        int img=postsImagesService.deletePsImgByPid(pid);
        int posts=postsService.deletePostsByPid(pid);
        //这里只用判断posts返回的值就OK了，因为数据库有关联约束，如果img和com有数据且没删除成功，那么posts也删不掉
        if (posts>0){
            return RespBean.ok("删除成功");
        }else {
            return RespBean.error("删除失败");
        }
    }
    @RequestMapping("updatePostsJsp")
    public String updatePostsJsp(@RequestParam(name = "pid") Integer pid,Model model){
        model.addAttribute("pid",pid);
        return "content/updatePosts";
    }
    /**修改操作*/
    @RequestMapping(value = "/updatePosts")//设置返回编码格式
    public String updatePosts(Posts posts,@RequestParam(name = "imgurl") String imgurl,Model model){
        //int pid =postsService.addPosts(posts);
        //前端传来的是url拼接的字符串，先分割下，看有几个图片地址
        String[] imgurlArray=imgurl.split(";");
        if(imgurlArray!=null){
            for (int i = 0; i <imgurlArray.length ; i++) {
                //先判断是否为空字符串，防止往数据库插入空值
                if (imgurlArray[i].equals("")||imgurlArray[i]==null){
                    break;
                }
                PostsImages p=new PostsImages();
                p.setPid(posts.getPid());
                p.setImgurl(imgurlArray[i].toString());
                postsImagesService.addPsImage(p);
            }
        }
        int i=postsService.updatePosts(posts);
        if(i!=0&&i>0){
            model.addAttribute("updatePostsMsg","修改成功");
            return "content/ModelMsg";
        }else {
            model.addAttribute("updatePostsMsg","修改失败");
            return "content/ModelMsg";
        }
    }
}
