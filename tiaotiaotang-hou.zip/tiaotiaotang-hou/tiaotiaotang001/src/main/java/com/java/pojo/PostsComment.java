package com.java.pojo;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import javax.persistence.*;

@Table(name = "ttt_p_comment")
public class PostsComment {
    @Id
    @Column(name = "p_cid")
    @GeneratedValue(generator = "JDBC")
    private Integer pCid;

    private Integer uid;

    private Integer pid;

    private Integer pCqq;



    @Column(name = "p_cping")
    private String pCping;

    @Column(name = "p_cdate")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private String pCdate;

    @Column(name = "p_cip")
    private String pCip;


    public Integer getpCqq() {
        return pCqq;
    }

    public void setpCqq(Integer pCqq) {
        this.pCqq = pCqq;
    }

    /**
     * @return p_cid
     */
    public Integer getpCid() {
        return pCid;
    }

    /**
     * @param pCid
     */
    public void setpCid(Integer pCid) {
        this.pCid = pCid;
    }

    /**
     * @return uid
     */
    public Integer getUid() {
        return uid;
    }

    /**
     * @param uid
     */
    public void setUid(Integer uid) {
        this.uid = uid;
    }

    /**
     * @return pid
     */
    public Integer getPid() {
        return pid;
    }

    /**
     * @param pid
     */
    public void setPid(Integer pid) {
        this.pid = pid;
    }

    /**
     * @return p_cping
     */
    public String getpCping() {
        return pCping;
    }

    /**
     * @param pCping
     */
    public void setpCping(String pCping) {
        this.pCping = pCping;
    }

    /**
     * @return p_cdate
     */
    public String getpCdate() {
        return pCdate;
    }

    /**
     * @param pCdate
     */
    public void setpCdate(String pCdate) {
        this.pCdate = pCdate;
    }

    /**
     * @return p_cip
     */
    public String getpCip() {
        return pCip;
    }

    /**
     * @param pCip
     */
    public void setpCip(String pCip) {
        this.pCip = pCip;
    }
}