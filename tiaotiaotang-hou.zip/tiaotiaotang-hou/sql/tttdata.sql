-- MySQL dump 10.13  Distrib 8.0.17, for macos10.14 (x86_64)
--
-- Host: localhost    Database: TiaoTiaoTang
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ttt_admin`
--

DROP TABLE IF EXISTS `ttt_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ttt_admin` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `aname` varchar(45) DEFAULT NULL,
  `apwd` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ttt_admin`
--

LOCK TABLES `ttt_admin` WRITE;
/*!40000 ALTER TABLE `ttt_admin` DISABLE KEYS */;
INSERT INTO `ttt_admin` VALUES (1,'admin','123456');
/*!40000 ALTER TABLE `ttt_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ttt_classify`
--

DROP TABLE IF EXISTS `ttt_classify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ttt_classify` (
  `classid` int(5) NOT NULL AUTO_INCREMENT,
  `classname` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`classid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ttt_classify`
--

LOCK TABLES `ttt_classify` WRITE;
/*!40000 ALTER TABLE `ttt_classify` DISABLE KEYS */;
INSERT INTO `ttt_classify` VALUES (1,'开发日志'),(2,'活动分享'),(3,'资源分享'),(4,'学习办公');
/*!40000 ALTER TABLE `ttt_classify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ttt_p_comment`
--

DROP TABLE IF EXISTS `ttt_p_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ttt_p_comment` (
  `p_cid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `p_cqq` int(11) DEFAULT NULL,
  `p_cping` varchar(200) DEFAULT NULL,
  `p_cdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `p_cip` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`p_cid`),
  KEY `fk_uid_idx` (`uid`),
  KEY `fk_pid_idx` (`pid`),
  KEY `fk_comment_pid_idx` (`pid`),
  CONSTRAINT `fk_comment_pid` FOREIGN KEY (`pid`) REFERENCES `ttt_posts` (`pid`),
  CONSTRAINT `fk_comment_uid` FOREIGN KEY (`uid`) REFERENCES `ttt_user` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ttt_p_comment`
--

LOCK TABLES `ttt_p_comment` WRITE;
/*!40000 ALTER TABLE `ttt_p_comment` DISABLE KEYS */;
INSERT INTO `ttt_p_comment` VALUES (4,10001,3,NULL,'哈哈哈，评论第一轮测试','2020-05-30 11:52:23',NULL),(5,10002,3,NULL,'自己评论自己','2020-05-30 11:53:10',NULL),(6,NULL,NULL,82371138,'哈哈哈测试',NULL,NULL),(7,NULL,98,82371138,'第一次评论测试','2020-06-12 19:58:58','223.90.251.168'),(8,NULL,98,82371138,'第一次时间戳出了问题，第二次测试','2020-06-13 09:03:03','223.90.251.168'),(9,NULL,98,907781015,'第三次测试','2020-06-13 09:04:04','223.90.251.168'),(10,NULL,98,82371138,'第4次测试','2020-06-13 09:05:05','223.90.251.168'),(11,NULL,98,82371138,'第5次测试','2020-06-13 09:08:08','223.90.251.168'),(12,NULL,98,82371138,'第5次测试','2020-06-13 09:09:09','223.90.251.168'),(13,NULL,97,82371138,'测试一下吧','2020-06-13 11:35:35','223.90.251.168'),(14,NULL,98,82371138,'再一次测试，快崩溃了','2020-06-13 13:01:01','223.90.251.168'),(17,NULL,30,82371138,'测试下','2020-06-16 02:46:46','223.90.251.218');
/*!40000 ALTER TABLE `ttt_p_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ttt_p_images`
--

DROP TABLE IF EXISTS `ttt_p_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ttt_p_images` (
  `imgid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `imgurl` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`imgid`),
  KEY `fk_pid_img_idx` (`pid`),
  CONSTRAINT `fk_pid_img` FOREIGN KEY (`pid`) REFERENCES `ttt_posts` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ttt_p_images`
--

LOCK TABLES `ttt_p_images` WRITE;
/*!40000 ALTER TABLE `ttt_p_images` DISABLE KEYS */;
INSERT INTO `ttt_p_images` VALUES (44,96,'2da8a94b-2407-4375-92b9-3a690bca3e8c.jpg'),(45,96,'ceea290d-4816-424f-9110-7c0d2fd2d02e.png'),(46,97,'f19c5700-1cad-4b40-8390-3259f7de45c7.jpg'),(59,97,'2bb37815-acf2-4ebc-9b86-ed5dc3912fc7.png'),(60,104,'4a78f010-0e9f-4f4a-823a-76c8ee8d4037.png'),(61,106,'43384f6f-16da-4342-8fcb-2018a64ddab3.png');
/*!40000 ALTER TABLE `ttt_p_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ttt_posts`
--

DROP TABLE IF EXISTS `ttt_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ttt_posts` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `classid` int(5) DEFAULT NULL,
  `pip` varchar(10) DEFAULT NULL,
  `pdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ptitle` varchar(50) DEFAULT NULL,
  `pcontent` varchar(600) DEFAULT NULL,
  PRIMARY KEY (`pid`),
  KEY `fk_uid_idx` (`uid`),
  KEY `fk_classid_idx` (`classid`),
  CONSTRAINT `fk_classid` FOREIGN KEY (`classid`) REFERENCES `ttt_classify` (`classid`),
  CONSTRAINT `fk_uid` FOREIGN KEY (`uid`) REFERENCES `ttt_user` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ttt_posts`
--

LOCK TABLES `ttt_posts` WRITE;
/*!40000 ALTER TABLE `ttt_posts` DISABLE KEYS */;
INSERT INTO `ttt_posts` VALUES (3,10002,1,NULL,'2020-05-30 10:20:25','关联测试','这是关联测试10002'),(4,10002,1,NULL,'2020-05-30 10:22:17','关联测试','关联测试10002'),(7,1,1,NULL,'2020-05-30 11:14:51','开发日志day1','昨天和今天在搭建数据库，已经基本完成，管理员，用户，贴子,以及贴子的评论，这些基础的设计基本完成，后期有待优化'),(8,1,1,NULL,'2020-05-31 12:54:52','开发日志day2','今天忙了一下午，对数据库做了些调整，在使用自动生成mapper和包工具时发现数据库的表名不能重复，否则会使用第一个表的字段，会跨数据库；搭了maven项目，建了ssm框架，并且通过controller实现了在页面能够显示所有注册用户的信息，目前为止，日志还是手动数据库插入'),(9,1,1,NULL,'2020-06-01 14:29:10','开发日志day3','今天写了一天，主要是前端页面，简单实现了单页的换肤功能，黑白皮肤通过js控制css进行切换，后期待优化；完成了导航栏，实现“文章分类”能够通过数据库的字段自动生成二级菜单，二级菜单有影响后面元素正常显示，最终通过子绝父相的定位方式解决这一问题；目前为止，日志还是手动数据库插入'),(10,1,1,NULL,'2020-06-02 13:55:18','开发日志day4','今天写的主要是后台，让主页能够通过ajax显示出数据库所有的文章，还有根据返回的*id去查对应的分类以及发帖人；学会了将ajax封装成方法，了解了async:false参数，默认为true：异步请求，false为同步请求，封装成方法体时应用同步请求，否则则会返回undefined；又了解了下有关pagehelper的用法，以及一些分页的实现，'),(11,1,1,NULL,'2020-06-03 13:23:19','开发日志day5','昨天晚上想了一下，正序显示数据库的贴子不是很友好，就想到了倒序查询，学习了tk.mybatis自带的条件查询Example用法，实现了根据pid(贴子ID)倒序显示所有；又研究了pageInfo的使用，又结合条件查询实现了倒序分页查询，模糊搜索分页查询，前台通过封装ajax实现了分页控制；从controller返回的pageInfo Json格式的数据，怎么也取不到pageInfo.list里面的东西，研究几小时发现是遍历方法不对，结合前面的遍历方式，最终使用原来的遍历方法解决问题，$.each(data.list,function (i,m) {m.pid}'),(12,1,1,NULL,'2020-06-05 13:53:02','开发日志day6','还是关于鼠标悬浮显示二级菜单的问题，根据兄弟元素判断时，就不能在二级菜单进行操作了，找到了新的mouseenter()和mouseleave()事件解决二级菜单闪烁问题；其次做了管理员的登陆以及页面css/js的设计，根据前端提交的表单，controller传入Admin的实体类，然后拿这个创建的Admin对象去数据库中查询，用mybatis自带的selectCount(admin)返回值为int类型；总的来说，今天写的不够多'),(27,1,1,NULL,'2020-06-06 13:43:04','开发日志day7','上午想着吧主页的css/js部分打包成文件，结果分页控制器出了问题，本来是直接用href=javascript“***”实现控制，研究一上午最后绑定了个onclick事件成功解决；下午写了添加文章的功能，以后可以直接在页面添加文章了；添加文章页做了特殊处理，没登陆后台的话不能访问添加页面，但会出现500错误，有待优化，晚上又写了主页的css，这个css和jquery是真的有些吃力。写出来的页面依旧很low。'),(28,1,2,NULL,'2020-06-08 07:19:31','活动','测试活动'),(29,1,3,NULL,'2020-06-08 07:19:31','资源','测试资源'),(30,1,4,NULL,'2020-06-08 07:19:31','学习办公','测试学习'),(35,1,1,NULL,'2020-06-08 14:18:18','开发日志day8','今天总的来说很顺利，实现了根据导航栏进行文章分类的显示，同时能够进行分页显示和分页控制，并写了css;在主页加了logo，每个篇文章的位置预留了头像位置，方便以后完善头像显示功能；之前写的文章添加页面，今天晚上进行了优化，原先都是input，今天加入了textarea标签，标签中不能有空格和回车，否则文字不能自动定位到左上角，并写了css，使页面美观一些，以后添加文章可以直接在页面添加了！'),(60,1,1,NULL,'2020-06-09 13:24:24','开发日志day9','今天实现了添加文章图片，可以在之前的后台添加文章时选择添加最多3张图片，技术有限，目前只能通过ajax上传，使用idea配置的本地tomcat会把图片上传到tomcat-root目录下，不能同步到idea项目文件中，但是在浏览器地址栏输入可以访问到，好像是idea的机制吧，使用maven-tomcat插件会同步文件夹到项目中，但是文字部分乱码了，各种百度最后在pom文件中配置tomcat加了一句<uriEncoding>UTF-8</uriEncoding>完美解决'),(95,1,1,NULL,'2020-06-10 13:47:35','开发日志day10','今天并没有写什么，只是研究了下css动画，之前老是想着jquery来做，忽略了css的强大，加入动画使页面更加美观了些；优化了之前报500的错误（没有登陆的情况下不能够对数据进行操作）;还有就是昨晚本来要睡了，遇到了图片上传的问题，一直报数组下标越界，研究1个半小时，结果是遍历对象单词写错了。。'),(96,1,1,NULL,'2020-06-11 08:19:19','第1次详情展示附带图片','第1次详情展示附带图片'),(97,1,1,NULL,'2020-06-11 08:22:32','第5次插入图片展示详情','第5次插入图片展示详情测试'),(98,1,1,NULL,'2020-06-11 13:04:04','开发日志day11','今天做的是单个文章的详情页，并显示其附属图片；本想加个根据qq获取用户的信息来验证后可以发表评论，找到了api，但是前端跨域请求只能用jsonp格式，状态虽然显示200，但是会被拦截，研究几个小时无果，今天先这样吧'),(99,1,1,NULL,'2020-06-13 13:09:09','开发日志day12','昨天研究了下用Java后台去用API，没想到成功了，后台不会出现跨域的问题，然后举一反三的又用了其他API，QQ获取头像和昵称，记录评论者的IP，返回IP对应的地址;把评论功能写完了，加了验证码环节，还有一些判断；评论区也写完了，今天写的不少，把单个的文章页面写完了，就是在评论区生成过程中异常缓慢，想着评论不会人多就没有加分页控制，看来前端这个逻辑要优化下'),(104,1,1,NULL,'2020-06-14 13:20:20','第90次插入测试标题','第90次插入测试标题'),(105,1,1,NULL,'2020-06-14 13:22:22','第91次插入测试标题d','第91次插入测试标题哈哈哈'),(106,1,1,NULL,'2020-06-14 13:50:50','开发日志day13','今天写了文章的删除和修改，实现了修改过程中点击图片可以从数据库中删除对应的img地址；评论区进行了分页处理，加载比之前稍微快了一点；增加了一个自动跳转页，在进行增，改文章时进行一个反馈；发现一个问题，封装好的js内ajax生成标签中的onclick时间没发调用，被调用的函数一直显示未定义，目前未解决，有待研究。'),(107,1,1,NULL,'2020-06-15 13:38:02','开发日志day14','今天写了文章分类的增删改；对所有评论封装进分页插件，实现分页控制,删除；实现了对管理员密码的修改；研究了java删除文件，把文件夹下的图片名称对比数据库中存在的img地址，对应不上的则删除，实现对之前ajax上传图片产生冗余图片的清理功能，到这里项目已经基本完成，剩下就是优化代码和美化前端页面'),(109,1,1,NULL,'2020-06-16 13:04:37','开发日志day15','到今天这个项目算是完成了，优化了登陆逻辑，避免退出管理员操作页面需要二次登陆的情况，发现个问题，web项目中放了html文件，但是运行tomcat之后，访问html文件时在页面直接输出源代码，整了一天没处理好，暂时先放弃html文件，项目以及打好了war包,整理下项目文件');
/*!40000 ALTER TABLE `ttt_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ttt_user`
--

DROP TABLE IF EXISTS `ttt_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ttt_user` (
  `uid` int(10) NOT NULL AUTO_INCREMENT,
  `uname` varchar(45) NOT NULL,
  `upwd` varchar(45) NOT NULL,
  `uimg` varchar(45) DEFAULT NULL,
  `udate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `uqq` int(10) DEFAULT NULL,
  `unickname` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=10004 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ttt_user`
--

LOCK TABLES `ttt_user` WRITE;
/*!40000 ALTER TABLE `ttt_user` DISABLE KEYS */;
INSERT INTO `ttt_user` VALUES (1,'admin','admin',NULL,'2020-05-29 13:22:21',82371138,'跳跳糖'),(10001,'zhangsan','12345',NULL,'2020-05-30 09:25:22',NULL,'测试人员001'),(10002,'lisi','123',NULL,'2020-05-30 09:25:54',NULL,'测试人员002');
/*!40000 ALTER TABLE `ttt_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-16 21:16:58
