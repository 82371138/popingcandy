use TiaoTiaoTang;
select * from `posts` p inner join `user` u on p.uid=u.uid;
#根据uid查询两个表的内容
select *from `posts`,`user` where posts.uid=10003 and posts.uid=`user`.uid;
#设置外键约束，删除时要把这个关了，0关闭，1开启；
SET FOREIGN_KEY_CHECKS=0;
select * from ttt_posts order by pid desc limit 0,3; 

select*from ttt_p_images where imgurl="f19c5700-1cad-4b40-8390-3259f7de45c7.jpg";